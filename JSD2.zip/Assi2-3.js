function num(...a){
    for(let i=0;i<a.length;i++){

    }
    console.log('number of arguments:', a.length);
    return a;
    
}
console.log(`argument on the screen:${num(3,5,6)}`);
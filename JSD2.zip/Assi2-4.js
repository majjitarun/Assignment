const login=(userName='CITIUSTECH',password='CITIUSTECH')=>
{
    console.log(`the user name ${userName}`);
    console.log(`the password is ${password}`);
}
login();

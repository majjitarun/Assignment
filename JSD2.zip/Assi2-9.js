function resultmax(arg1,arg2,arg3){
    return Math.max(arg1,arg2,arg3);
 
  }
  console.log(`maximum:${resultmax(9,2,4)}`);